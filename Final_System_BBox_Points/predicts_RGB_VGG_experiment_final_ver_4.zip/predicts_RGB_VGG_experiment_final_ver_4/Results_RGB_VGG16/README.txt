Experiment performed using RGB and VGG
 
 INPUTS 

Name Experiment : Results_RGB_VGG16 
Numbers of channels : 128 
Images : 1 
Deep_layer : 5 
n_segment : 100 
compactness : 10 
sigma : 1 
threshold : 180 
file_per_image : True 
file_iou_image : True 
